export const inventory = [
  {
    id: 1,
    name: "Nike Air Max 20",
    price: 1000,
    image: "../shoes/2000.png",
    bgColor: "antiquewhite",
  },

  {
    id: 2,
    name: "Nike Air Max 30",
    price: 2000,
    image: "../shoes/2001.png",
    bgColor: "aliceblue",
  },

  {
    id: 3,
    name: "Nike Air Min 30",
    price: 3000,
    image: "../shoes/2002.png",
    bgColor: "beige",
  },

  {
    id: 4,
    name: "Leather Sneakers",
    price: 4000,
    image: "../shoes/2003.png",
    bgColor: "cornsilk",
  },

  {
    id: 5,
    name: "Reebok Sand 20",
    price: 5000,
    image: "../shoes/2004.png",
    bgColor: "honeydew",
  },

  {
    id: 6,
    name: "PUMA Fire 20",
    price: 6000,
    image: "../shoes/2005.png",
    bgColor: "lightcyan",
  },

  {
    id: 7,
    name: "Leather Sneakers 2",
    price: 7000,
    image: "../shoes/2007.png",
    bgColor: "lemonchiffon",
  },

  {
    id: 8,
    name: "Reebok Sand 50",
    price: 8000,
    image: "../shoes/2006.png",
    bgColor: "lavender",
  },

  {
    id: 9,
    name: "PUMA Flame 60",
    price: 9000,
    image: "../shoes/2009.png",
    bgColor: "lightcyan",
  },
];
